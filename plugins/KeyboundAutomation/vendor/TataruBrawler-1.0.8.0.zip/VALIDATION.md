# Tataru Brawler local validation

- The plugin name, internal name, assembly, namespace, command, build paths, and package names use Tataru Brawler.
- The old support tab and external donation link are absent. Startup defaults enable diagnostic recording, automatic typing, and Play on MapID 1359; their settings checkboxes are absent.
- The Cyberpunk theme applies to the plugin window and its tabs, popups, controls, and buttons. Style pushes and pops are balanced. An offline native ImGui preview rendered and was inspected.
- 246 offline checks pass, including three consecutive automatic queue cycles and a stop before the fourth registration. They do not send real keyboard events or interact with the live game.
- Native NPC interaction, registration, duty entry, repeat queueing, and appearance in the actual game still require an in game check.
