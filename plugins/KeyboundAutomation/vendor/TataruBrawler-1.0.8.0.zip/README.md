# Tataru Brawler

Tataru Brawler is a local Dalamud plugin for the Keybound Brawler activity in FFXIV. It reads visible prompts and types English or Japanese answers. The plugin also has a repeat queue for the Keybound Registrar and a Cyberpunk styled interface.

## Use

1. Open `/tatarubrawler` in game.
2. Enter Keybound Square and approach the Keybound Registrar. **Auto queue on lobby entry** registers and accepts the matching duty ready popup. It repeats after each game until **Stop auto queue** is pressed. **Pause auto queue** holds the next registration step without turning off typing.
3. The circular arrows start a separate manual loop. **Number of runs** applies only to that manual loop.
4. In Settings, adjust typing speed and optional background English input. The Diagnostics tab has recording controls.

Diagnostic recording, automatic typing when a game begins, and enabling Play on MapID 1359 are on by default. Their settings checkboxes are hidden. Pressing the main Stop control still stops typing for the current visit. **Stop auto queue** stops only the automatic queue and does not cancel a duty queue already submitted.

## Local installation

Extract the ZIP and add `TataruBrawler.dll` as a Dalamud dev plugin. Disable any other installed copy that controls Keybound Brawler while testing. This local build is not a GitHub repository release.

## Build

Run `tools/Build-Release.ps1` from PowerShell. The script builds the plugin, runs offline checks, and creates a ZIP in `artifacts/`. The plugin's native NPC, registration, and repeat flow still needs in game verification.

License and preserved source attribution are in `LICENSE` and `NOTICE`.
